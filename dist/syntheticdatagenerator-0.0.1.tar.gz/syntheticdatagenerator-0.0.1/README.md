# syntheticdatagenerator
A package to generate synthetic time series data
